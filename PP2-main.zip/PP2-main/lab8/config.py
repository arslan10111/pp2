# Database connection parameters
params = {
    "host": "localhost",
    "database": "phonebook_db",
    "user": "postgres",
    "password": "your_password",
    "port": "5432"
}